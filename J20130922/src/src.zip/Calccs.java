
public class Calccs {

	public double plus(String a, String b)
	{
		return Double.parseDouble(a) + Double.parseDouble(b);
	}

	public double minus(String a, String b)
	{
		return Double.parseDouble(a) - Double.parseDouble(b);
	}

	public double pplus(String a, String b)
	{
		return Double.parseDouble(a) * Double.parseDouble(b);
	}

	public double mminus(String a, String b)
	{
		return Double.parseDouble(a) / Double.parseDouble(b);
	}

}
